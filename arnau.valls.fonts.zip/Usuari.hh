/** @file Usuari.hh
    @brief Especificació de la classe Usuari
*/
#ifndef USUARI_HH
#define USUARI_HH

/// \cond
#include <iostream>
#include <string>
#include <list>
/// \endcond

using namespace std;

/** @class Usuari
    @brief Representa el tipus Usuari
*/
class Usuari{
    private:
    public:
        //Constructors
        /** @brief Crea un Usuari amb curs = 0
        \pre Cert
        \post Crea un Usuari amb curs = 0 (no està inscrit)
        */
        Usuari();

        /** @brief Crea un Usuari amb curs = nc
        \pre nc >=0
        \post Crea un Usuari amb curs = nc 
        */
        Usuari(int nc);

        //Modificadors     
        /** @brief Canvia el curs de l'usuari per nc
        \pre nc >= 0
        \post curs = nc
        */
        void modificar_curs(int nc);

        //Consultors
        

        /** @brief Comprova que l'usuari que hagi completat el curs
        \pre Està inscrit a un curs
        \post Comprova que l'usuari que hagi completat el curs
        */
        bool curs_completat();




};
#endif