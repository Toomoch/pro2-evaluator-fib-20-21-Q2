/** @file Sesio.hh
    @brief Especificació de la classe Sesio
*/
#ifndef SESIO_HH
#define SESIO_HH

/// \cond
#include <iostream>
/// \endcond
using namespace std;

/** @class Sesio
    @brief Representa el tipus Sesio
*/
class Sesio{
    private:
    public:
    //Constructors
    /** @brief Contructor predeterminat
    \pre Cert
    \post Crea una sesió buida
    */
    Sesio();

    //Consultor
    /** @brief Retorna el numero de problemes que té la sessió
    \pre Cert
    \post Retorna el numero de problemes que té la sessió
    */
    int numero_problemes();

    /** @brief Retorna els identificadors dels problemes que té la sessió
    \pre Existeix la sessió i no és buida
    \post Retorna els identificadors dels problemes que té la sessió
    */
    int identificadors_problemes();


};
#endif