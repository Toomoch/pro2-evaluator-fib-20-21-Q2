/** @mainpage
	En el mòdul program.cc es troba el programa principal de la plataforma Evaluator, una col·lecció de problemes programació.

*/

/** @file program.cc
    @brief Programa principal
    
    <em>Evaluator d'Usuaris</em>.
*/
/// \cond
#include <iostream>
/// \endcond
#include "Cjt_problemes.hh"
#include "Cjt_sesions.hh"
#include "Cjt_usuaris.hh"
#include "Cjt_cursos.hh"
using namespace std;

int main () 
{
    int nprob;
    cin>>nprob;
    Cjt_problemes p;
    string temp;
    p.llegir_Cjt_problemes(nprob);

    int nsesio;
    cin>>nsesio;
    Cjt_sesions q;
    q.llegir_cjt_sesions(nsesio);

    int ncurs;
    cin>>ncurs;
    Cjt_cursos c;
    c.llegeix_cjt_cursos(ncurs);
    
    int m;
    cin>>m;
    Cjt_usuaris u;
    u.llegir_usuaris(m);
    
    string comando;
    cin>>comando;
    while (comando!="fin")
    {
        if (comando == "nuevo_problema" or comando == "np")
        {
            string prob;
            cin>>prob;
            p.afegeix_Cjt_problemes(prob);
        }
        else if (comando == "nueva_sesion" or comando == "ns")
        {
            string sesi;
            cin>>sesi;
            q.afegir_sesio();
        }
        else if (comando == "nuevo_curso" or comando == "nc")
        {
            string cur;
            cin>>cur;
            c.afegir_curs_al_cjt(cur);
        }
        else if (comando == "alta_usuario" or comando == "a")
        {
            string usernou;
            cin>>usernou;
            u.afegir_usuari(usernou);
        }
        else if (comando == "baja_usuario" or comando == "b")
        {
            string userdel;
            cin>>userdel;
            u.eliminar_usuari(userdel);
        }
        else if (comando == "inscribir_curso" or comando == "c")
        {
            string usr;
            int cursusr;
            u.inscriure_usuari_curs(usr, cursusr);
        }
        else if (comando == "curso_usuario" or comando == "cu")
        {
            string usrcurs;
            cin>>usrcurs;
            u.curs_inscrit(usrcurs);
        }
        else if (comando == "sesion_problema" or comando == "sp")
        {
            string sesprob;
            int cursprob;
            c.ses_prob_curs(cursprob, sesprob);
        }
        else if (comando == "problemas_resueltos" or comando == "pr")
        {
            string usresol;
            cin>>usresol;
            u.escriu_prob_resolts(usresol);
        }
        else if (comando == "problemas_enviables" or comando == "pe")
        {
            string usrenv;
            cin>>usrenv;
            u.escriu_prob_resolts(usrenv);
        }
        else if (comando == "envio" or comando == "e")
        {
            string userenv, probenv;
            int r;
            u.enviament(userenv, probenv, r);
        }
        else if (comando == "listar_problemas" or comando == "ep")
        {
            p.escriure_Cjt_problemes();
        }
        else if (comando == "listar_sesiones" or comando == "es")
        {
            q.escriure_cjt_sesio();
        }
        else if (comando == "listar_cursos" or comando == "ec")
        {
            c.escriu_cjt_cursos();
        }
        else if (comando == "listar_usuarios" or comando == "eu")
        {
            u.llistar_usuaris();
        }
        cin>>comando;
    }
}