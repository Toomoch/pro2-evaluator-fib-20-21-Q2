/** @file Cjt_problemes.hh
    @brief Especificació de la classe Cjt_problemes
*/
#ifndef CJT_PROBLEMES_HH
#define CJT_PROBLEMES_HH

/// \cond
#include <iostream>
#include <string>
/// \endcond

#include "Problema.hh"
using namespace std;

/** @class Cjt_problemes
    @brief Representa el tipus Cjt_problemes
*/
class Cjt_problemes {

private:
public:

    //Constructors
    /** @brief Constructor predeterminat
    \pre Cert
    \post Crea un Conjunt de problemes buit
    */
    Cjt_problemes();

    //Modificadors
    /** @brief Afegeix un problema al Conjunt 
    \pre Cert
    \post Afegeix un problema al Conjunt de problemes
    */
    void afegeix_Cjt_problemes(string prob);

    /** @brief Llegeix un Conjunt
    \pre Nombre de problemes > 0
    \post Llegeix un Conjunt de problemes
    */
    void llegir_Cjt_problemes(int np);

    //Consultor
    /** @brief Escriu el Conjunt
    \pre Cert
    \post Retorna el Conjunt de problemes
    */
    void escriure_Cjt_problemes();

    


    
};

#endif