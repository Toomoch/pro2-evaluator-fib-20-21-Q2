/** @file Cjt_cursos.hh
    @brief Especificació de la classe Cjt_cursos
*/
#ifndef CJT_CURSOS_HH
#define CJT_CURSOS_HH

/// \cond
#include <iostream>
#include <vector>
/// \endcond
#include "Curs.hh"
using namespace std;

/** @class Cjt_cursos
    @brief Representa el tipus Cjt_cursos
*/
class Cjt_cursos{
    private:

    public:

    //Constructors
    /** @brief Constructor predeterminat
    \pre Cert
    \post Crea un Conjunt de cursos buit
    */
    Cjt_cursos();

    //Modificadors
    /** @brief Modificador d'un conjunt de cursos
    \pre Nombre de cursos > 0
    \post Llegeix un conjunt de cursos
    */
    void llegeix_cjt_cursos(int ncurs);

    /** @brief Afegir un curs al conjunt de cursos
    \pre Nou curs no existent al conjunt
    \post Afegeix el curs donat al conjunt de cursos
    */
    void afegir_curs_al_cjt(string cur);

    //Consultors
    /** @brief Consulta la sesió del problema
    \pre Cert
    \post Consulta la sesió del problema donat en el curs donat
    */
    void ses_prob_curs(int c, string p);

    /** @brief Escriu els cursos pertanyents al conjunt
    \pre Cert
    \post Escriu els cursos pertanyents al conjunt
    */
    void escriu_cjt_cursos();

    

};
#endif