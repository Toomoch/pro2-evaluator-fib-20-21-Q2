/** @file Cjt_sesions.hh
    @brief Especificació de la classe Cjt_sesions
*/
#ifndef CJT_SESIONS_HH
#define CJT_SESIONS_HH

/// \cond
#include <iostream>
#include <vector>
/// \endcond
#include "Sesio.hh"

using namespace std;

/** @class Cjt_sesions
    @brief Representa el tipus Cjt_sesions
*/
class Cjt_sesions{
    private:
    public:
    //Constructors
    /** @brief Crea un conjunt de sesions
    \pre Cert
    \post El resultat es un conjunt de sesions buit
    */
    Cjt_sesions();

    //Modificadors
    /** @brief Afegir una sesió al conjunt
    \pre La nova sesió no és existent dins del conjunt
    \post Afegeix una sesió al conjunt de sesions
    */
    void afegir_sesio();

    /** @brief Llegir un conjunt de sesions
    \pre Nombre de sesions > 0
    \post Llegeix un conjunt de sesions
    */
    void llegir_cjt_sesions(int nsesio);

    //Consultors
    /** @brief Escriure un conjunt de sesions
    \pre Cert
    \post Escriu un conjunt de sesions
    */
    void escriure_cjt_sesio();

    /** @brief Escriure una sesió del conjunt
    \pre Cert
    \post Retorna una sesió 
    */
    void escriure_sesio(string s);
};
#endif