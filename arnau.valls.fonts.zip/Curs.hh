/** @file Curs.hh
    @brief Especificació de la classe Curs
*/
#ifndef CURS_HH
#define CURS_HH

/// \cond
#include <iostream>
#include <string>
/// \endcond
using namespace std;

/** @class Curs
    @brief Representa el tipus Curs
*/
class Curs{
    private:
    public:
//Constructors
/** @brief Constructor predeterminat
    \pre Cert
    \post Crea un Curs buit
    */
    Curs();
    
};

#endif