/** @file Cjt_usuaris.hh
    @brief Especificació de la classe Cjt_usuaris
*/
#ifndef CJT_USUARI_HH
#define CJT_USUARI_HH

/// \cond
#include <iostream>
#include <string>
#include <list>
/// \endcond
#include "Usuari.hh"

using namespace std;

/** @class Cjt_usuaris
    @brief Representa el tipus Cjt_usuaris
*/
class Cjt_usuaris{
    private:
    public:
        //Constructors
        /** @brief Constructor predeterminat
        \pre Cert
        \post Crea un Usuari amb curs = 0 (no està inscrit)
        */
        Cjt_usuaris();

        //Modificadors
        /** @brief Afegeix un usuari amb id = u al Cjt d'Usuaris
        \pre Usuari no existent al conjunt
        \post Nou element al conjunt d'Usuaris amb id = u
        */
        void afegir_usuari(string u);
        
        /** @brief Elimina l'usuari del Cjt d'usuaris amb id = u
        \pre Cert
        \post Elimina l'usuari de la llista d'usuaris amb id = u
        */
        void eliminar_usuari(string u);
        
        /** @brief Omple el conjunt d'usuaris 
        \pre Cert
        \post Conjunt d'Usuaris omplert amb els Usuaris donats
        */
        void llegir_usuaris(int nu);
        
        /** @brief Inscriu l'usuari amb id = u al curs c
        \pre L'usuari ha acabat el curs o no té curs
        \post Inscriu l'usuari amb id = u al curs c
        */
        void inscriure_usuari_curs(string u, int c);
        
        /** @brief Realitza un enviament de problema de l'Usuari u
        \pre Cert
        \post Realitza un enviament de problema de l'Usuari u
        */
        void enviament(string u, string p, int r);

        //Consultors
        /** @brief Retorna el numero del curs en que està inscrit l'usuari
        \pre Cert
        \post Retorna el numero del curs en que està inscrit l'usuari (en cas contrari retorna 0)
        */
        int curs_inscrit(string u);

        /** @brief Escriu els problemes resolts del Usuari
        \pre Cert
        \post Escriu els problemes resolts del Usuari
        */
        void escriu_prob_resolts(string u);

        /** @brief Escriu els problemes enviables del Usuari
        \pre Cert
        \post Escriu els problemes enviables del Usuari
        */
        void escriu_prob_enviables(string u);

        /** @brief Escriu els Usuaris pertanyents als conjunt
        \pre Cert
        \post Escriu els Usuaris del conjunt amb els seus enviaments respectius
        */
        void llistar_usuaris();


        

        



};
#endif