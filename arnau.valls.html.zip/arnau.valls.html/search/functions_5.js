var searchData=
[
  ['modificar_5fcurs_92',['modificar_curs',['../classUsuari.html#a469c61e0d6d298ffc490db0ff7b7f38b',1,'Usuari']]]
];
