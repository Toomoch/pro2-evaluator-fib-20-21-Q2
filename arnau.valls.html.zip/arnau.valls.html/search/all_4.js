var searchData=
[
  ['llegeix_5fcjt_5fcursos_30',['llegeix_cjt_cursos',['../classCjt__cursos.html#a7ccd6bd657371839284cf2560c2d3cd0',1,'Cjt_cursos']]],
  ['llegir_5fcjt_5fproblemes_31',['llegir_Cjt_problemes',['../classCjt__problemes.html#ab32ee388b744c0f7788bd6122ae38362',1,'Cjt_problemes']]],
  ['llegir_5fcjt_5fsesions_32',['llegir_cjt_sesions',['../classCjt__sesions.html#a8d63d54eea02f232b7a5c34fc0a655e1',1,'Cjt_sesions']]],
  ['llegir_5fusuaris_33',['llegir_usuaris',['../classCjt__usuaris.html#af37cff47d3246f26fc7e2623a0c464e5',1,'Cjt_usuaris']]],
  ['llistar_5fusuaris_34',['llistar_usuaris',['../classCjt__usuaris.html#a3e907a9c904b505729f8a9f0c2443c8c',1,'Cjt_usuaris']]]
];
