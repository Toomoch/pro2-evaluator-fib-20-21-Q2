var searchData=
[
  ['numero_5fproblemes_36',['numero_problemes',['../classSesio.html#a6d969dd00736ba60d80264ed56cdab0a',1,'Sesio']]]
];
