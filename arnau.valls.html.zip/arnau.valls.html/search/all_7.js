var searchData=
[
  ['problema_37',['Problema',['../classProblema.html',1,'Problema'],['../classProblema.html#a9d81af5f3f42a1b4354ad8f3c022fca3',1,'Problema::Problema()']]],
  ['problema_2ehh_38',['Problema.hh',['../Problema_8hh.html',1,'']]],
  ['program_2ecc_39',['program.cc',['../program_8cc.html',1,'']]]
];
