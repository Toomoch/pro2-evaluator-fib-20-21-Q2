var searchData=
[
  ['problema_50',['Problema',['../classProblema.html',1,'']]]
];
