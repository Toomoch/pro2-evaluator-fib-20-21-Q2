var searchData=
[
  ['eliminar_5fusuari_75',['eliminar_usuari',['../classCjt__usuaris.html#a2c12e1b63a6115231cf9528392f5a9a4',1,'Cjt_usuaris']]],
  ['env_5fexit_76',['env_exit',['../classProblema.html#a0bd6b169d17544b0c507f78e2ec77c5c',1,'Problema']]],
  ['env_5ftotals_77',['env_totals',['../classProblema.html#a89fb6770d4b2ef5755216d16db154fad',1,'Problema']]],
  ['enviament_78',['enviament',['../classCjt__usuaris.html#af3883f32ad21c28cd7359bb0b2325d4b',1,'Cjt_usuaris']]],
  ['escriu_5fcjt_5fcursos_79',['escriu_cjt_cursos',['../classCjt__cursos.html#a905fc72cfbf6dfdaf0f88271421309da',1,'Cjt_cursos']]],
  ['escriu_5fprob_5fenviables_80',['escriu_prob_enviables',['../classCjt__usuaris.html#ae3e6bb8f6f0c56b9767e47519fec7b75',1,'Cjt_usuaris']]],
  ['escriu_5fprob_5fresolts_81',['escriu_prob_resolts',['../classCjt__usuaris.html#a3dd40f95bb2b1c199ad18445c63a9762',1,'Cjt_usuaris']]],
  ['escriure_5fcjt_5fproblemes_82',['escriure_Cjt_problemes',['../classCjt__problemes.html#a964c8d27a9b29ec35f248d48a896e62a',1,'Cjt_problemes']]],
  ['escriure_5fcjt_5fsesio_83',['escriure_cjt_sesio',['../classCjt__sesions.html#ac0e2da84c06191cab1b0b7bbc338630a',1,'Cjt_sesions']]],
  ['escriure_5fsesio_84',['escriure_sesio',['../classCjt__sesions.html#aba4668129c2e68763d781489565349fd',1,'Cjt_sesions']]]
];
