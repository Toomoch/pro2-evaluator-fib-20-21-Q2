var searchData=
[
  ['afegeix_5fcjt_5fproblemes_0',['afegeix_Cjt_problemes',['../classCjt__problemes.html#a172fa643bf8f48149c5fe1082c23abd8',1,'Cjt_problemes']]],
  ['afegeix_5fenv_5fexit_1',['afegeix_env_exit',['../classProblema.html#ac72f12a50f89ed7c5e404f1ecbe27866',1,'Problema']]],
  ['afegeix_5fenv_5ftotal_2',['afegeix_env_total',['../classProblema.html#acba29ed7318a2ff86be90c78d5fe3563',1,'Problema']]],
  ['afegir_5fcurs_5fal_5fcjt_3',['afegir_curs_al_cjt',['../classCjt__cursos.html#a93f1d14bffafa51b57098de4e6ec5e9f',1,'Cjt_cursos']]],
  ['afegir_5fsesio_4',['afegir_sesio',['../classCjt__sesions.html#a14652b4bcc648a4486ac61b10c0af474',1,'Cjt_sesions']]],
  ['afegir_5fusuari_5',['afegir_usuari',['../classCjt__usuaris.html#a73c75394561b73fae6091cc567995f51',1,'Cjt_usuaris']]]
];
