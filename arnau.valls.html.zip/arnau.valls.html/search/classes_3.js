var searchData=
[
  ['usuari_52',['Usuari',['../classUsuari.html',1,'']]]
];
