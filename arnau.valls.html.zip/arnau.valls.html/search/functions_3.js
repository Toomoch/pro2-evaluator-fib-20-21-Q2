var searchData=
[
  ['identificadors_5fproblemes_85',['identificadors_problemes',['../classSesio.html#a84e84d6c1885189eb3c5ea807f6972b0',1,'Sesio']]],
  ['inscriure_5fusuari_5fcurs_86',['inscriure_usuari_curs',['../classCjt__usuaris.html#ac12a2b8fb0d9e72ebf99882ddfd69475',1,'Cjt_usuaris']]]
];
