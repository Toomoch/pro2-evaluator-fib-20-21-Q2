var searchData=
[
  ['problema_94',['Problema',['../classProblema.html#a9d81af5f3f42a1b4354ad8f3c022fca3',1,'Problema']]]
];
