var searchData=
[
  ['usuari_97',['Usuari',['../classUsuari.html#ac6a1fbc3d6967c6de677580c60dfaaf4',1,'Usuari::Usuari()'],['../classUsuari.html#a198f95c4f1f1c6bacaf78ff90e658d18',1,'Usuari::Usuari(int nc)']]]
];
